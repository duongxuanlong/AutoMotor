﻿using UnityEngine;
using System.Collections;

public class InputManagers : MonoBehaviour {


}
