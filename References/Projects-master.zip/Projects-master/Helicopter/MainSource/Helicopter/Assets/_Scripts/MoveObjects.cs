﻿using UnityEngine;
using System.Collections;

public class MoveObjects : MonoBehaviour {

	protected void FixedUpdate()
	{
		
	}

	protected void HandleMovementX(float x)
	{
	}

	protected void HandleMovementY(float y)
	{
	}

	protected void HandleLayers()
	{
	}
}
